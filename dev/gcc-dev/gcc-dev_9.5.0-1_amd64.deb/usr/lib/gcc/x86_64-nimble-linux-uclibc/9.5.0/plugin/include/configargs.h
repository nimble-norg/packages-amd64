/* Generated automatically. */
static const char configuration_arguments[] = "./configure --host=x86_64-nimble-linux-uclibc --target=x86_64-nimble-linux-uclibc --enable-languages=c --disable-libstdcxx --disable-rpath --disable-rpath-linking --with-gmp-lib=/home/mir/sharedbuild/lib --with-gmp-include=/home/mir/sharedbuild/usr/include --with-mpc-lib=/home/mir/sharedbuild/lib --with-mpc-include=/home/mir/sharedbuild/usr/include/ --with-mpfr-include=/home/mir/sharedbuild/usr/include/ --with-mpfr-lib=/home/mir/sharedbuild/lib --disable-bootstrap --disable-bootstrapping --enable-host-pie --disable-nls --disable-multilib --without-multilib --prefix=/usr --bindir=/usr/bin --libdir=/usr/lib --sysconfdir=/etc --includedir=/usr/include --sbindir=/usr/sbin --disable-libquadmath --disable-libquadmath-support --disable-ada --enable-decimal-float=dpd --disable-libgomp --disable-libatomic --disable-libsanitizer";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "x86-64" } };
