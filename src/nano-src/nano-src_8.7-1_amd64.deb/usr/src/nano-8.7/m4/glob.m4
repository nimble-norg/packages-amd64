# glob.m4
# serial 34
dnl Copyright (C) 2005-2007, 2009-2025 Free Software Foundation, Inc.
dnl This file is free software; the Free Software Foundation
dnl gives unlimited permission to copy and/or distribute it,
dnl with or without modifications, as long as this notice is preserved.
dnl This file is offered as-is, without any warranty.

# The glob module assumes you want GNU glob, with glob_pattern_p etc,
# rather than vanilla POSIX glob.  This means your code should
# always include <glob.h> for the glob prototypes.

AC_DEFUN([gl_GLOB],
[
  AC_REQUIRE([gl_GLOB_H])

  AC_CHECK_FUNCS_ONCE([glob_pattern_p])
  gl_CHECK_FUNCS_ANDROID([glob], [[#include <glob.h>]])
  if test $ac_cv_func_glob = no; then
    HAVE_GLOB=0
    case "$gl_cv_onwards_func_glob" in
      future*) REPLACE_GLOB=1 ;;
    esac
  else

    AC_CACHE_CHECK([whether glob overflows the stack with recursive calls],
      [gl_cv_glob_overflows_stack],
      [AC_RUN_IFELSE(
         [AC_LANG_SOURCE([[
            #include <stddef.h>
            #include <stdlib.h>
            #include <string.h>
            #include <glob.h>
            int
            main (void)
            {
              /* Test that glob with many trailing slashes or slashes following
                 a wildcard does not overflow the stack as it did in glibc 2.42
                 and earlier.  */
              char *p = malloc (10000);
              glob_t g;
              int result = 0;
              if (p != NULL)
                {
                  /* This test fails on glibc <= 2.42 (stack overflow),
                     Android.  */
                  memset (p, '/', 9999);
                  p[9999] = '\0';
                  if (glob (p, 0, NULL, &g) != 0)
                    result |= 1;
                  globfree (&g);
                  #if !defined __ANDROID__
                  /* This test fails on Cygwin 3.6.4 (return value
                     GLOB_ABORTED).  */
                  memset (p, '/', 9997);
                  p[1] = '*';
                  strcpy (p + 9997, "sh");
                  if (glob (p, 0, NULL, &g) != 0)
                    result |= 2;
                  globfree (&g);
                  #endif
                }
              return result;
            }]])],
         [gl_cv_glob_overflows_stack=no],
         [gl_cv_glob_overflows_stack=yes],
         [case "$host_os" in
                             # Guess yes on glibc systems.
            *-gnu* | gnu*)   gl_cv_glob_overflows_stack="guessing yes" ;;
                             # Guess yes on Cygwin.
            cygwin*)         gl_cv_glob_overflows_stack="guessing yes" ;;
                             # Guess yes on Android.
            linux*-android*) gl_cv_glob_overflows_stack="guessing yes" ;;
                             # If we don't know, obey --enable-cross-guesses.
            *)               gl_cv_glob_overflows_stack="$gl_cross_guess_inverted" ;;
          esac
         ])
      ])

    case $gl_cv_glob_overflows_stack in
      *yes) REPLACE_GLOB=1 ;;
      *) REPLACE_GLOB=0 ;;
    esac

    if test $REPLACE_GLOB = 0; then
      AC_CACHE_CHECK([whether glob lists broken symlinks],
                     [gl_cv_glob_lists_symlinks],
        [if test $cross_compiling != yes; then
           if ln -s conf-doesntexist conf$$-globtest 2>/dev/null; then
             gl_cv_glob_lists_symlinks=maybe
           else
             # If we can't make a symlink, then we cannot test this issue.  Be
             # pessimistic about this.
             gl_cv_glob_lists_symlinks=no
           fi
           if test $gl_cv_glob_lists_symlinks = maybe; then
             AC_RUN_IFELSE(
               [AC_LANG_PROGRAM(
                  [[#include <stddef.h>
                    #include <glob.h>]],
                  [[glob_t found;
                    if (glob ("conf*-globtest", 0, NULL, &found) == GLOB_NOMATCH)
                      return 1;
                    globfree (&found);
                  ]])],
               [gl_cv_glob_lists_symlinks=yes],
               [gl_cv_glob_lists_symlinks=no],
               [dnl We don't get here.
                :
               ])
           fi
           rm -f conf$$-globtest
         else
           gl_cv_glob_lists_symlinks="$gl_cross_guess_normal"
         fi
        ])
      case "$gl_cv_glob_lists_symlinks" in
        *yes) ;;
        *) REPLACE_GLOB=1 ;;
      esac
    fi

    if test $REPLACE_GLOB = 0; then
      AC_CACHE_CHECK([whether glob NOTDIR*/ omits symlink to nondir],
                     [gl_cv_glob_omit_nondir_symlinks],
        [if test $cross_compiling != yes; then
           if ln -s conf$$-file conf$$-globtest 2>/dev/null && touch conf$$-file
           then
             gl_cv_glob_omit_nondir_symlinks=maybe
           else
             # If we can't make a symlink, then we cannot test this issue.  Be
             # pessimistic about this.
             gl_cv_glob_omit_nondir_symlinks=no
           fi
           if test $gl_cv_glob_omit_nondir_symlinks = maybe; then
             AC_RUN_IFELSE(
               [AC_LANG_PROGRAM(
                  [[#include <stddef.h>
                    #include <glob.h>]],
                  [[glob_t found;
                    if (glob ("conf*-globtest/", 0, NULL, &found) != GLOB_NOMATCH)
                      return 1;
                    globfree (&found);
                  ]])],
               [gl_cv_glob_omit_nondir_symlinks=yes],
               [gl_cv_glob_omit_nondir_symlinks=no],
               [dnl We don't get here.
                :
               ])
           fi
           rm -f conf$$-file conf$$-globtest
         else
           gl_cv_glob_omit_nondir_symlinks="$gl_cross_guess_normal"
         fi
        ])
      case "$gl_cv_glob_omit_nondir_symlinks" in
        *yes) ;;
        *) REPLACE_GLOB=1 ;;
      esac
    fi

  fi

  if test $ac_cv_func_glob_pattern_p = no; then
    HAVE_GLOB_PATTERN_P=0
  else
    if test $REPLACE_GLOB = 1; then
      REPLACE_GLOB_PATTERN_P=1
    fi
  fi

  if test $HAVE_GLOB = 0 || test $REPLACE_GLOB = 1; then
    gl_REPLACE_GLOB_H
  fi
])

# Prerequisites of lib/glob.c and lib/globfree.c.
AC_DEFUN([gl_PREREQ_GLOB],
[
  AC_REQUIRE([gl_CHECK_TYPE_STRUCT_DIRENT_D_TYPE])
  AC_CHECK_HEADERS_ONCE([unistd.h])
  gl_CHECK_FUNCS_ANDROID([getlogin_r], [[#include <unistd.h>]])
  gl_CHECK_FUNCS_ANDROID([getpwnam_r], [[#include <pwd.h>]])
])
