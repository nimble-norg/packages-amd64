@load "readdir"

{ print }
