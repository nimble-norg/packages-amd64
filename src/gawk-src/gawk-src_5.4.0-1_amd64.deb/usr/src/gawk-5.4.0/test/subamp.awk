{ sub(/[[:lower:]]/, "&") ; print }
