BEGIN {
	print "Hello"
}
