/****************************************************************************
 * Copyright 2020-2024,2025 Thomas E. Dickey                                *
 * Copyright 1998-2009,2010 Free Software Foundation, Inc.                  *
 *                                                                          *
 * Permission is hereby granted, free of charge, to any person obtaining a  *
 * copy of this software and associated documentation files (the            *
 * "Software"), to deal in the Software without restriction, including      *
 * without limitation the rights to use, copy, modify, merge, publish,      *
 * distribute, distribute with modifications, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is    *
 * furnished to do so, subject to the following conditions:                 *
 *                                                                          *
 * The above copyright notice and this permission notice shall be included  *
 * in all copies or substantial portions of the Software.                   *
 *                                                                          *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS  *
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF               *
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.   *
 * IN NO EVENT SHALL THE ABOVE COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,   *
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR    *
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR    *
 * THE USE OR OTHER DEALINGS IN THE SOFTWARE.                               *
 *                                                                          *
 * Except as contained in this notice, the name(s) of the above copyright   *
 * holders shall not be used in advertising or otherwise to promote the     *
 * sale, use or other dealings in this Software without prior written       *
 * authorization.                                                           *
 ****************************************************************************/

/****************************************************************************
 *  Author: Zeyd M. Ben-Halim <zmbenhal@netcom.com> 1992,1995               *
 *     and: Eric S. Raymond <esr@snark.thyrsus.com>                         *
 *     and: Thomas E. Dickey                        2002                    *
 *     and: Juergen Pfeifer                         2009                    *
 ****************************************************************************/

/*
 *	lib_kernel.c
 *
 *	Misc. low-level routines:
 *		erasechar()
 *		killchar()
 *		flushinp()
 *
 * The baudrate() and delay_output() functions could logically live here,
 * but are in other modules to reduce the static-link size of programs
 * that use only these facilities.
 */

#include <curses.priv.h>

MODULE_ID("$Id: lib_kernel.c,v 1.40 2025/12/23 09:09:50 tom Exp $")

#ifdef TERMIOS
static int
_nc_vdisable(void)
{
    int value = -1;
#if defined(_POSIX_VDISABLE) && HAVE_UNISTD_H
    value = _POSIX_VDISABLE;
#endif
#if defined(_PC_VDISABLE) && HAVE_FPATHCONF
    if (value == -1) {
	value = (int) fpathconf(0, _PC_VDISABLE);
	if (value == -1) {
	    value = 0377;
	}
    }
#elif defined(VDISABLE)
    if (value == -1)
	value = VDISABLE;
#endif
    return value;
}
#endif /* TERMIOS */

/*
 *	erasechar()
 *
 *	Return erase character as given in cur_term->Ottyb.
 *
 */

NCURSES_EXPORT(char)
NCURSES_SP_NAME(erasechar) (NCURSES_SP_DCL0)
{
    int result = ERR;
    TERMINAL *termp = TerminalOf(SP_PARM);

    T((T_CALLED("erasechar(%p)"), (void *) SP_PARM));

    if (termp != NULL) {
#ifdef TERMIOS
	result = termp->Ottyb.c_cc[VERASE];
	if (result == _nc_vdisable())
	    result = ERR;
#elif defined(USE_WIN32CON_DRIVER)
	result = ERR;
#else
	result = termp->Ottyb.sg_erase;
#endif
    }
    returnChar((char) result);
}

#if NCURSES_SP_FUNCS
NCURSES_EXPORT(char)
erasechar(void)
{
    return NCURSES_SP_NAME(erasechar) (CURRENT_SCREEN);
}
#endif

/*
 *	killchar()
 *
 *	Return kill character as given in cur_term->Ottyb.
 *
 */

NCURSES_EXPORT(char)
NCURSES_SP_NAME(killchar) (NCURSES_SP_DCL0)
{
    int result = ERR;
    TERMINAL *termp = TerminalOf(SP_PARM);

    T((T_CALLED("killchar(%p)"), (void *) SP_PARM));

    if (termp != NULL) {
#ifdef TERMIOS
	result = termp->Ottyb.c_cc[VKILL];
	if (result == _nc_vdisable())
	    result = ERR;
#elif defined(USE_WIN32CON_DRIVER)
	result = ERR;
#else
	result = termp->Ottyb.sg_kill;
#endif
    }
    returnChar((char) result);
}

#if NCURSES_SP_FUNCS
NCURSES_EXPORT(char)
killchar(void)
{
    return NCURSES_SP_NAME(killchar) (CURRENT_SCREEN);
}
#endif

static void
flush_input(int fd)
{
#if defined(TERMIOS)
    tcflush(fd, TCIFLUSH);
#else /* !TERMIOS */
    errno = 0;
    do {
#if defined(USE_WIN32CON_DRIVER)
	_nc_console_flush(_nc_console_fd2handle(fd));
#else
	ioctl(fd, TIOCFLUSH, 0);
#endif
    } while
	(errno == EINTR);
#endif
}

/*
 *	flushinp()
 *
 *	Flush any input on tty
 */

NCURSES_EXPORT(int)
NCURSES_SP_NAME(flushinp) (NCURSES_SP_DCL0)
{
    T((T_CALLED("flushinp(%p)"), (void *) SP_PARM));

    if (SP_PARM != NULL) {
	if (NC_ISATTY(SP_PARM->_ifd))
	    flush_input(SP_PARM->_ifd);
	else if (NC_ISATTY(SP_PARM->_ofd))
	    flush_input(SP_PARM->_ofd);
	if (SP_PARM) {
	    SP_PARM->_fifohead = -1;
	    SP_PARM->_fifotail = 0;
	    SP_PARM->_fifopeek = 0;
	}
	returnCode(OK);
    }
    returnCode(ERR);
}

#if NCURSES_SP_FUNCS
NCURSES_EXPORT(int)
flushinp(void)
{
    return NCURSES_SP_NAME(flushinp) (CURRENT_SCREEN);
}
#endif
